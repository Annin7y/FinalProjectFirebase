package com.udacity.gradle.builditbiggerfirebase;

public interface EndpointsAsyncTaskInterface
{
    void returnJokeData(String result);
}
